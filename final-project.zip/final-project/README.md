﻿# 基于Django的实现的一个简单的淘宝网站
这是一个Python基于Django的课程设计

## 环境搭建
python 3.8
Django是2.2


## 运行
```python manage.py runserver``` 



