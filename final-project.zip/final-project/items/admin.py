from django.contrib import admin

from .models import ItemList

admin.site.register(ItemList)


# Register your models here.
